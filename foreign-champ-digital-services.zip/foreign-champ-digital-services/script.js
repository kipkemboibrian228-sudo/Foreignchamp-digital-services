// Add your WhatsApp number in international format, without + or spaces. Example: 2547XXXXXXXX
const WHATSAPP_NUMBER = "2547XXXXXXXX";
const cta = document.getElementById("whatsapp-cta");
const message = encodeURIComponent("Hello Foreign Champ Digital Services! I'm interested in a website starting at KSh 3,000. Please share more details.");
if (cta) {
  if (/^254\d{9}$/.test(WHATSAPP_NUMBER)) {
    cta.href = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;
  } else {
    cta.href = "#contact";
    cta.addEventListener("click", (event) => {
      event.preventDefault();
      alert("Please add your Kenyan WhatsApp number in script.js before publishing.");
    });
  }
}
const toggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
if (toggle && nav) {
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  }));
}
document.getElementById("year").textContent = new Date().getFullYear();
